package TaskService;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {

    @Test
    void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Sample Task", "Good Description");

        service.addTask(task);

        assertEquals(task, service.getTask("12345"));
    }

    @Test
    void testAddDuplicateTask() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Sample Task", "Good description");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> service.addTask(task));
    }

    @Test
    void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Sample Task", "Description");

        service.addTask(task);
        service.deleteTask("12345");

        assertNull(service.getTask("12345"));
    }

    @Test
    void testDeleteNonExistentTask() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("12345"));
    }

    @Test
    void testUpdateTask() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Sample Task", "Good description.");

        service.addTask(task);

        service.updateTask("12345", "Different Task", "Different Description");

        Task updatedTask = service.getTask("12345");
        assertEquals("Different Task", updatedTask.getName());
        assertEquals("Different Description", updatedTask.getDescription());
    }

    @Test
    void testUpdateNonExistentTask() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () ->
            service.updateTask("12345", "Different Task", "Different Description"));
    }

    @Test
    void testPartialUpdateTask() {
        TaskService service = new TaskService();
        Task task = new Task("12345", "Sample Task", "Test Description");

        service.addTask(task);

        service.updateTask("12345", null, "Different Description");

        Task updatedTask = service.getTask("12345");
        assertEquals("Sample Task", updatedTask.getName());
        assertEquals("Different Description", updatedTask.getDescription());
    }
}
