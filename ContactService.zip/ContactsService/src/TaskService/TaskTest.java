package TaskService;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task task = new Task("12345", "Sample Task", "Test Description");
        assertEquals("12345", task.getTaskId());
        assertEquals("Sample Task", task.getName());
        assertEquals("This is a test task description.", task.getDescription());
    }

    @Test
    void testTaskCreationInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Sample Task", "Good Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Sample Task", "Good Description"));
    }

    @Test
    void testTaskCreationInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> new Task("12345", null, "Good Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345", "Really, really long and therefore invalid thingy hopefully maybe yep", "Good Description"));
    }

    @Test
    void testSetValidName() {
        Task task = new Task("12345", "Sample Task", "Good Description");
        task.setName("Updated Task");
        assertEquals("Updated Task", task.getName());
    }

    @Test
    void testSetInvalidName() {
        Task task = new Task("12345", "Sample Task", "Good Description");
        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
        assertThrows(IllegalArgumentException.class, () -> task.setName("Really, really long and therefore invalid thingy hopefully maybe yep"));
    }

    @Test
    void testSetValidDescription() {
        Task task = new Task("12345", "Sample Task", "Good Description");
        task.setDescription("Different Description");
        assertEquals("Different Description", task.getDescription());
    }

    @Test
    void testSetInvalidDescription() {
        Task task = new Task("12345", "Sample Task", "Valid Description");
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription("Really, really long and therefore invalid thingy hopefully maybe yep, especially this one because it has to be more than 50"));
    }
}
